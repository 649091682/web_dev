Juncong Li
Andrew ID: Juncong Li

Project Name: Snipperclips

This is inspired by the Switch game, Snipperclips. And I wrote that game in Pygame.
The goal of the game is to match the players' shape with the puzzle shape, which is typically in the middle of the window. The players pass that level by a 'good' match, shown in the progress bar. If the percentage is 100%, you can pass the level.

Run the project:

If you want to play the normal mode, which means just in one computer, simply run TP3_Code.py. Click 'help' or 'normal mode'.

If you want to play the online mode, you need to run server.py first. After you see 'Waiting for a connection, server started', you can run TP3_Code.py and click 'online mode'. To test that, you need to run run TP3_Code.py and click 'online mode' twice, since there are two players.

Notice that in normal mode, there are 10 levels and in online mode, there are 4 levels. Because pickle cannot dump mask object in pygame, the players cannot cut each other. Online mode only supports easy levels.


Libraries need to install: pygame 2.0.0, socket


Short cut: 

ESC can help you back to the main menu if you are running any mode or in help mode.

For testers' convenience, you can do that:
In TP3_Code.py, line 371. Self.requirement is the difficulty. It describes how much you should fit the puzzle shape. It is 0.96. You can set it to 0.1, which is much more easier to pass the level and see what all the levels look like. 0.96 is quite a fair requirement.



