
# Modified from https://www.youtube.com/watch?v=McoDjOCb2Zo
import socket
from _thread import *
import sys
from player import Player1
import pickle

# Store some information
class PlayerInfo(object):
    def __init__(self, x, y, angle):
        self.offsetx = x
        self.offsety = y
        self.angle = angle

#hostname = socket.gethostname()
#ip = socket.gethostbyname(hostname)
server = '127.0.0.1'
port = 5555

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try:
    s.bind((server, port))
except socket.error as e:
    str(e)

s.listen(2)
print("Waiting for a connection, server started")

# The starting position of player1, player2
players = [PlayerInfo(0, 0, 0),
           PlayerInfo(500, 0, 0)]

def threaded_client(conn, player):
    conn.send(pickle.dumps(players[player]))
    reply = ""
    while True:
        try:
            data = pickle.loads(conn.recv(2048*10))
            players[player] = data
            
            if not data:
                print("disconnected")
                break
            else:
                if player == 1:
                    reply = players[0]
                else:
                    reply = players[1]
                #print("Received: ", data)
                #print("Sending: ", reply)

            conn.sendall(pickle.dumps(reply))
        except:
            print("Error in threaded client")
            break
    print("Lost connection")
    conn.close()

currentPlayer = 0

while True:
    conn, addr = s.accept()
    print("Connect to : ", addr)

    start_new_thread(threaded_client, (conn, currentPlayer))
    #currentPlayer += 1
    currentPlayer = 1
