# Name: Juncong Li
# Andrew ID: juncongl


'''
This game is mainly based on a switch game called Snipperclips.
What's new is that the users can customize their own puzzle shape without
much effort.
For drawing the players, I just used the shapes of the image and I never drew 
the images. I only need the mask of the image.
'''


import random, sys, time, math
import pygame as pg
from pygame.locals import *


class Player1(pg.sprite.Sprite):
    def __init__(self):
        pg.sprite.Sprite.__init__(self)
        # Just need the shape of the image
        self.startImage = pg.image.load('playerShape.png')
        self.image = self.startImage
        #self.rect = self.image.get_rect()

        # This mask is really important and it represents the player
        self.startMask = pg.mask.from_surface(self.image)
        # Initialize the mask
        self.mask = self.startMask

        self.canvasWidth = 1200
        self.canvasHeight = 800
        (self.width, self.height) = self.mask.get_size()
        self.offsetx = 0
        self.offsety = 0
        self.speedx = 2
        self.speedy = 0 # Based on gravity
        self.gravity = 1
        self.tiptoeSpeedy = 20
        self.acceleartion = 10
        self.onGround = False
        self.color = (0,255,0)
        self.angle = 0
        self.rotateSpeed = 1
        (self.startCentroidx, self.startCentroidy) = self.startMask.centroid()
        (self.centroidx, self.centroidy) = \
        (self.startCentroidx, self.startCentroidy)
        self.hasSave = False

    def drawPlayer(self, surface):
        self.outline = self.mask.outline()
        realOutline = self.getRealOutline(self.outline)
        # https://stackoverflow.com/questions/
        # 23071965/display-pygame-mask-on-screen
        pg.draw.polygon(surface, self.color, realOutline, 0)

    '''
    The function shows how player 1 can control the game.
    'a' and 'd' are moving to left and right.
    'w' is tiptoing and 's' is crounching (doesn't work now)
    '''
    def move(self, keyPressed, otherPlayer):
        self.gravity = 1
        if keyPressed[K_d]:
            self.offsetx += self.speedx
        if keyPressed[K_a]:
            self.offsetx -= self.speedx
        if keyPressed[K_s]:
            self.crouch()
        if keyPressed[K_w]:
            self.tiptoe()
        if keyPressed[K_LSHIFT]:
            self.jump()
        if keyPressed[K_f]:
            self.cutOther(otherPlayer)
        if keyPressed[K_c]:
            self.mask = pg.mask.from_surface(self.startImage)
        if keyPressed[K_q]:
            self.angle += self.rotateSpeed
            self.rotate()
        if keyPressed[K_e]:
            self.angle -= self.rotateSpeed
            self.rotate()
        if keyPressed[K_z]:
            self.saveShape()
        if keyPressed[K_x]:
            if self.hasSave:
                self.getShape()

        self.gravityEffect()

    def saveShape(self):
        self.saveMask = self.mask.copy()
        self.saveX, self.saveY = self.offsetx, self.offsety
        self.saveAngle = self.angle
        self.hasSave = True
        
    def getShape(self):
        self.mask = self.saveMask.copy()
        self.offsetx, self.offsety = self.saveX, self.saveY
        self.angle = self.saveAngle

    # Rotate. Have padding issues
    # Need to fix the centroid
    def rotate(self):
        (self.oldCentroidx, self.oldCentroidy) = self.mask.centroid()
        self.image = pg.transform.rotate(self.startImage, self.angle)
        self.rotatedMask = pg.mask.from_surface(self.image)
        self.mask = self.rotatedMask
        (self.centroidx, self.centroidy) = self.mask.centroid()
        # Fix the centroid
        self.offsetx -= (self.centroidx - self.oldCentroidx)
        self.offsety -= (self.centroidy - self.oldCentroidy)
        
    def gravityEffect(self):
        self.speedy += self.gravity
        self.offsety += self.speedy

        if (self.offsety + self.height + self.width/2 - 
        (self.startCentroidy - self.centroidy) >= self.canvasHeight):

            self.offsety = (self.canvasHeight - self.height - self.width/2
                            + (self.startCentroidy - self.centroidy))
            self.speedy = 0
            self.onGround = True

    # Jump with gravity
    # Just give the player a upward speed
    def jump(self):
        if self.onGround:
            self.speedy = -20
            self.onGround = False

    # The player stands on tiptoe
    # Set gravity to 0 to stablize the player
    def tiptoe(self):
        if self.onGround:
            self.gravity = 0
            if (self.offsety > self.canvasHeight \
                    - self.height - self.width*3/4):
                self.offsety -= self.tiptoeSpeedy
            else:
                self.offsety = self.canvasHeight \
                    - self.height - self.width*3/4

    # Cannot work so far
    def crouch(self):
        if self.onGround:
            self.gravity = 0
            if (self.offsety > self.canvasHeight - self.height):
                self.offsety += self.tiptoeSpeedy      
            else:
                self.offsety = self.canvasHeight - self.height
        
    # The pygame.mask.Mask.outline's return outline coordinates are alwas
    # near the origin. So I need to calculate real coordinates by adding 
    # the offset.
    def getRealOutline(self, outline):
        realOutline = [None] * len(outline)
        for i in range(len(outline)):
            (x, y) = outline[i]
            dx, dy = self.offsetx, self.offsety
            realOutline[i] = (x + dx, y + dy)
        return realOutline
    
    # Cut another player
    # If another player is cut into two separate pieces, reserve the larger one
    def cutOther(self, otherPlayer):
        otherPlayer.mask.erase(self.mask, 
        (int(self.offsetx - otherPlayer.offsetx), 
         int(self.offsety - otherPlayer.offsety)))
        otherPlayer.mask = otherPlayer.mask.connected_component()

# Player2 inherits most parts of Player1, but I need to overwrite something
# Change player2's color
# Overwrite move(self, keyPressed), so that I can change the keys
class Player2(Player1):
    def __init__(self):
        super().__init__()
        self.color = (255,0,0)
        # Born in another place
        self.offsetx = self.canvasWidth - self.width
    
    # Key controling has been changed.
    def move(self, keyPressed, otherPlayer):
        self.gravity = 1
        if keyPressed[K_SEMICOLON]:
            self.offsetx += self.speedx
        if keyPressed[K_k]:
            self.offsetx -= self.speedx
        if keyPressed[K_l]:
            self.crouch()
        if keyPressed[K_o]:
            self.tiptoe()
        if keyPressed[K_RSHIFT]:
            self.jump()
        if keyPressed[K_j]:
            self.cutOther(otherPlayer)
        if keyPressed[K_m]:
            self.mask = pg.mask.from_surface(self.image)        
        if keyPressed[K_i]:
            self.angle += self.rotateSpeed
            self.rotate()
        if keyPressed[K_p]:
            self.angle -= self.rotateSpeed
            self.rotate()
        if keyPressed[K_PERIOD]:
            self.saveShape()
        if keyPressed[K_COMMA]:
            if self.hasSave:
                self.getShape()

        self.gravityEffect()

class Puzzle(object):
    def __init__(self):
        self.imageList = ["puzzle1.png", "puzzle2.png"]
        self.image = pg.image.load("puzzle1.png")
        self.rect = self.image.get_rect()
        # This mask is really important and it represents the player
        self.mask = pg.mask.from_surface(self.image)
        self.canvasWidth = 1200
        self.canvasHeight = 800
        (self.width, self.height) = self.mask.get_size()
        self.offsety = self.canvasHeight - self.height-50
        #self.offsety = self.canvasHeight - self.height-103
        self.offsetx = self.canvasWidth/2 - self.width/2
        self.color = (0, 0, 0)
        
    def drawPuzzle(self, surface):
        self.outline = self.mask.outline()
        realOutline = self.getRealOutline(self.outline)
        pg.draw.lines(surface, self.color, True, realOutline, 1)

    def getRealOutline(self, outline):
        realOutline = [None] * len(outline)
        for i in range(len(outline)):
            (x, y) = outline[i]
            dx, dy = self.offsetx, self.offsety
            realOutline[i] = (x + dx, y + dy)
        return realOutline



# Run the game with this class
class Game(object):

    # Set up the screen and create two player
    def __init__(self):
        self.fpsClock = pg.time.Clock()
        self.fpsClock.tick(60)
        self.canvasWidth = 1200
        self.canvasHeight = 800
        self.screen = pg.display.set_mode((self.canvasWidth, self.canvasHeight))
        self.player1 = Player1()
        self.player2 = Player2()
        self.puzzle = Puzzle()
        self.running = True
        self.fit = 0


    def runGame(self):
        pg.init()
        self.mainLoop()

    def mainLoop(self):
        running = True
        while running:
            for event in pg.event.get():
                if event.type == KEYDOWN:
                    if event.key == K_ESCAPE:
                        running = False
                elif event.type == QUIT:
                    running = False
            self.screen.fill((255,255,255))
            self.update()
            pg.display.update()
            self.checkWin()

    def update(self):
        keyPressed = pg.key.get_pressed()
        self.player1.move(keyPressed, self.player2)
        self.player1.drawPlayer(self.screen)
        self.player2.move(keyPressed, self.player1)
        self.player2.drawPlayer(self.screen)
        self.puzzle.drawPuzzle(self.screen)
        self.drawProgressBar()

    def checkWin(self):
        '''
        # Must copy because I use some destructive functions
        self.totalMask = self.player1.mask.copy()
        # Get the total mask
        self.totalMask.draw(self.player2.mask, 
                            (int(self.player1.offsetx - self.player2.offsetx), 
                            int(self.player1.offsety - self.player2.offsety)))
        totalArea = self.totalMask.count()
        
        overlapArea = self.totalMask.overlap_area(self.puzzle.mask,
                            (int(self.player1.offsetx - self.puzzle.offsetx), 
                            int(self.player1.offsety - self.puzzle.offsety)))
                            '''
        '''
        totalMask = self.player1.mask.convolve(self.player2.mask, None, 
                            (int(self.player1.offsetx - self.player2.offsetx), 
                            int(self.player1.offsety - self.player2.offsety)))

        totalArea = totalMask.count()
        player1Area = self.player1.mask.count()
        player2Area = self.player2.mask.count()
        playerOverlap = self.player1.mask.overlap_mask(self.player2.mask,
                            (int(self.player1.offsetx - self.player2.offsetx), 
                            int(self.player1.offsety - self.player2.offsety)))
        playerOverlapArea = playerOverlap.count()
        playerTotalArea = player1Area + player2Area - playerOverlapArea
        #totalOverlapWithPuzzle = 
        puzzleArea = self.puzzle.mask.count()
        print("player1", player1Area)
        print("playeroverlap: ", playerOverlapArea)
        print("totalArea ", totalArea)
        print("totalplayer: ", playerTotalArea)
        print("puzzle: ", puzzleArea)
        '''
        player1InPuzzle = self.player1.mask.overlap_mask(self.puzzle.mask,
                            (int(self.puzzle.offsetx - self.player1.offsetx), 
                            int(self.puzzle.offsety - self.player1.offsety)))

        player2InPuzzle = self.player2.mask.overlap_mask(self.puzzle.mask,
                            (int(self.puzzle.offsetx - self.player2.offsetx), 
                            int(self.puzzle.offsety - self.player2.offsety)))

        overlapInPuzzle = player1InPuzzle.overlap_mask(player2InPuzzle,
                            (int(self.player2.offsetx - self.player1.offsetx), 
                            int(self.player2.offsety - self.player1.offsety)))

        playerOverlap = self.player1.mask.overlap_mask(self.player2.mask,
                            (int(self.player2.offsetx - self.player1.offsetx), 
                            int(self.player2.offsety - self.player1.offsety)))
        
        player1Area = self.player1.mask.count()
        player2Area = self.player2.mask.count()
        playerOverlapArea = playerOverlap.count() 
        player1InPuzzleArea = player1InPuzzle.count()
        player2InPuzzleArea = player2InPuzzle.count()
        overlapInPuzzle = overlapInPuzzle.count()
        puzzleArea = self.puzzle.mask.count()
        player1Area = self.player1.mask.count()
        totalPlayerArea = player1Area + player2Area - playerOverlapArea
        inPuzzleTotalPlayerArea = player1InPuzzleArea + player2InPuzzleArea \
            - overlapInPuzzle
        outPuzzleTotalPlayerArea = totalPlayerArea - inPuzzleTotalPlayerArea

        self.fit = (inPuzzleTotalPlayerArea - outPuzzleTotalPlayerArea) \
                    / puzzleArea
        print(self.fit)
        #print("player1Area: ", player1Area)
        #print("player1InPuzzleArea: ", player1InPuzzleArea)
        #print("player2InPuzzleArea: ", player2InPuzzleArea)
        #print("overlapInPuzzle: ", overlapInPuzzle)
        #print("puzzleArea: ", puzzleArea)

        #self.completion = overlapArea/puzzleArea

        #print(self.completion)

    def drawProgressBar(self):
        if self.fit <= 0:
            persentage = 0
        else:
            # Impossible to get a perfect fit.
            # So you can get 100% if you have a fit of 0.95
            persentage = int(self.fit/0.9*100)
            if persentage > 100:
                persentage = 100
        
        width = 300
        height = 100
        percentageWidth = width*persentage*0.01
        emptyBar = pg.Rect(self.canvasWidth/2 - width/2, height,
                            width, height)
        topLeft = (self.canvasWidth/2 - width/2, height)
        topRight = (self.canvasWidth/2 - width/2 + width, height)
        downLeft = (self.canvasWidth/2 - width/2, height + height)
        downRight = (self.canvasWidth/2 - width/2 + width, height + height)
        progressBar = pg.Rect(self.canvasWidth/2 - width/2, height,
                            percentageWidth, height)
        pg.draw.rect(self.screen, (0,0,255), progressBar)                
        pg.draw.lines(self.screen, (0,0,0), True, 
                    [topLeft, topRight, downRight, downLeft],width = 3)


if __name__ == '__main__':
    game = Game()
    game.runGame()
    pg.quit()

