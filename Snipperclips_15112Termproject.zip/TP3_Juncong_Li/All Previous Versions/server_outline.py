import socket
from _thread import *
import sys

#hostname = socket.gethostname()
#ip = socket.gethostbyname(hostname)
server = '192.168.3.6'
port = 5555

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try:
    s.bind((server, port))
except socket.error as e:
    str(e)

s.listen(2)
print("Waiting for a connection, server started")

def readOutline(string):
    strList = string.split(',')
    outline = [ ]
    for s in strList:
        sList = s.split(' ')
        posX = int(sList[0])
        posY = int(sList[1])
        outline.append((posX, posY))
    # Outline[0] is a tuple with offsetX and offsetY
    # Outline[1:] is the list of outline tuples
    return outline[0], outline[1:]

def makePos(tuple, outline):
    string = ''
    # Add offsetX and offsetY
    string += str(tuple[0]) + ' ' + str(tuple[1]) + ','
    # Add all outline positions
    for s in outline:
        string += str(s[0]) + ' ' + str(s[1]) + ','
    return string[:-1]

# The starting position of player1, player2
pos = [(0, 0),(500, 0)]

def threaded_client(conn, player):
    conn.send(str.encode(makePos(pos[player])))
    reply = ""
    while True:
        try:
            data = readPos(conn.recv(2048).decode())
            pos[player] = data
            

            if not data:
                print("disconnected")
                break
            else:
                if player == 1:
                    reply = pos[0]
                else:
                    reply = pos[1]
                print("Received: ", data)
                print("Sending: ", reply)

            conn.sendall(str.encode(makePos(reply)))
        except:
            print("Error in threaded client")
            break
    print("Lost connection")
    conn.close()

currentPlayer = 0

while True:
    conn, addr = s.accept()
    print("Connect to : ", addr)

    start_new_thread(threaded_client, (conn, currentPlayer))
    currentPlayer += 1
