# Name: Juncong Li
# Andrew ID: juncongl


'''
This game is mainly based on a switch game called Snipperclips.
What's new is that the users can customize their own puzzle shape without
much effort.
For drawing the players, I just used the shapes of the image and I never drew 
the images. I only need the mask of the image.
Most use of pygame methods, if not specifically cited, are inspired from 
https://www.pygame.org/docs/.
Sound effects are from https://offers.adobe.com/en/na/audition/offers/ \
audition_dlc/AdobeAuditionDLCSFX.html?cq_ck=1407955238126&wcmmode=disabled.
'''


import random, sys, time, math
import pygame as pg
from pygame.locals import *
import pygame.gfxdraw
import socket
import pickle

# Modified from https://www.youtube.com/watch?v=McoDjOCb2Zo
class Network:
    def __init__(self):
        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        #hostname = socket.gethostname()
        #ip = socket.gethostbyname(hostname)
        self.server = '127.0.0.1'
        self.port = 5555
        self.addr = (self.server, self.port)
        self.info = self.connect()
    
    def getInfo(self):
        return self.info

    # Connect with the server
    def connect(self):
        try:
            self.client.connect(self.addr)
            return pickle.loads(self.client.recv(2048*10))
        except:
            pass
    
    # Send massage to the server
    def send(self, data):
        try:
            self.client.send(pickle.dumps(data))
            return pickle.loads(self.client.recv(2048*10))
        except socket.error as e:
            print(e)


# Store some information
class PlayerInfo(object):
    def __init__(self, x, y, outline):
        self.offsetx = x
        self.offsety = y
        self.outline = outline


class Player1(object):
    def __init__(self):
        #pg.sprite.Sprite.__init__(self)
        # Just need the shape of the image
        self.startImage = pg.image.load('playerShape.png')
        self.image = self.startImage
        self.footUp = pg.image.load('footUp.png')
        self.footDown = pg.image.load('footDown.png')
        self.leftFoot = self.rightFoot = self.footUp
        self.footRect = self.footUp.get_rect()
        self.footWidth = self.footRect.width
        self.footHeight = self.footRect.height
        self.footTemple = 0
        # self.rect = self.image.get_rect()
        # This mask is really important and it represents the player
        self.startMask = pg.mask.from_surface(self.image)
        # Initialize the mask
        self.mask = self.startMask
        self.outline = self.mask.outline()

        self.canvasWidth = 1200
        self.canvasHeight = 800
        (self.width, self.height) = self.mask.get_size()
        self.offsetx = 0
        self.offsety = 0
        self.speedx = 2
        self.speedy = 0 # Based on gravity
        self.gravity = 1
        self.tiptoeSpeedy = 5
        self.acceleartion = 10
        self.onGround = False
        self.color = (255, 192, 203)
        self.angle = 0
        self.rotateSpeed = 1
        (self.startCentroidx, self.startCentroidy) = self.startMask.centroid()
        (self.centroidx, self.centroidy) = \
        (self.startCentroidx, self.startCentroidy)
        self.hasSave = False
        leftFootPositionx = self.offsetx + self.centroidx - \
                            self.footWidth - 5
        rightFootPositionx = self.offsetx + self.centroidx + 5
        self.leftFootPositionx = self.offsetx + self.centroidx - \
                            self.footWidth - 5
        self.rightFootPositionx = self.offsetx + self.centroidx + 5
        self.leftFootPositiony = self.rightFootPositiony = \
                    self.offsety + self.centroidy + 105
        self.stepOffset = 0
        self.isStepping = False
        self.savePositionx = 100

    def drawPlayer(self, surface):
        self.outline = self.mask.outline()
        if (len(self.outline) <= 2):
            self.__init__()
        realOutline = self.getRealOutline(self.outline)
        # Idea from https://stackoverflow.com/questions/
        # 23071965/display-pygame-mask-on-screen
        self.drawFoot(surface)
        pg.draw.polygon(surface, self.color, realOutline)
        if self.hasSave:
            self.drawSavedShape(surface)

    def drawSavedShape(self, surface):
        saveOutline = self.saveMask.outline()
        realOutline = [None] * len(saveOutline)
        for i in range(len(saveOutline)):
            (x, y) = saveOutline[i]
            dx, dy = self.savePositionx, 10
            realOutline[i] = (x + dx + self.startCentroidx - self.saveCentroidx,
                            y + dy + self.startCentroidy - self.saveCentroidy)
        pg.draw.polygon(surface, self.color, realOutline)


    def drawFoot(self, surface):
        self.leftFootPositionx = self.offsetx + self.centroidx - \
                            self.footWidth - 5
        self.rightFootPositionx = self.offsetx + self.centroidx + 5
        self.leftFootPositiony = self.rightFootPositiony = \
                    self.offsety + self.centroidy + 105
        # Left leg
        surface.blit(self.leftFoot, (self.leftFootPositionx, \
                                    self.leftFootPositiony - self.stepOffset))
        # Right leg
        surface.blit(self.rightFoot, (self.rightFootPositionx, \
                                    self.rightFootPositiony - self.stepOffset))
    
    def stepping(self):
        
        #time = pg.time.get_ticks()
        #self.leftFoot = self.footUp
        self.isStepping = False
        

    '''
    The function shows how player 1 can control the game.
    'a' and 'd' are moving to left and right.
    'w' is tiptoing and 's' is crounching (doesn't work now)
    '''
    def move(self, keyPressed, otherPlayer):
        self.gravity = 1
        if keyPressed[K_d]:
            self.offsetx += self.speedx
            #self.stepping()
        if keyPressed[K_a]:
            self.offsetx -= self.speedx
            #self.stepping()
        if keyPressed[K_s]:
            self.crouch()
        if keyPressed[K_w]:
            self.tiptoe()
        if keyPressed[K_LSHIFT]:
            self.jump()
        if keyPressed[K_f]:
            self.cutOther(otherPlayer)
        if keyPressed[K_c]:
            self.__init__()
            #self.mask = pg.mask.from_surface(self.startImage)
        if keyPressed[K_q]:
            self.angle += self.rotateSpeed
            self.rotate()
        if keyPressed[K_e]:
            self.angle -= self.rotateSpeed
            self.rotate()
        if keyPressed[K_z]:
            self.saveShape()
        if keyPressed[K_x]:
            if self.hasSave:
                self.getShape()

        self.gravityEffect()

    def saveShape(self):
        self.saveMask = self.mask.copy()
        (self.saveX, self.saveY) = (self.offsetx, self.offsety)
        self.saveAngle = self.angle
        (self.saveCentroidx, self.saveCentroidy) = (self.centroidx,
                                                    self.centroidy)
        self.hasSave = True
        
    def getShape(self):
        self.angle = self.saveAngle
        self.offsetx, self.offsety = self.saveX, self.saveY
        self.mask = self.saveMask.copy()

    # Rotate. Have padding issues
    # Need to fix the centroid
    def rotate(self):
        (self.oldCentroidx, self.oldCentroidy) = self.mask.centroid()
        self.image = pg.transform.rotate(self.startImage, self.angle)
        self.rotatedMask = pg.mask.from_surface(self.image)
        self.mask = self.rotatedMask
        (self.centroidx, self.centroidy) = self.mask.centroid()
        # Fix the centroid
        self.offsetx -= (self.centroidx - self.oldCentroidx)
        self.offsety -= (self.centroidy - self.oldCentroidy)
        
    def gravityEffect(self):
        self.speedy += self.gravity
        self.offsety += self.speedy

        if (self.offsety + 2*self.height -
        (self.startCentroidy - self.centroidy) >= self.canvasHeight):

            self.offsety = (self.canvasHeight - 2*self.height
                            + (self.startCentroidy - self.centroidy))
            self.speedy = 0
            self.onGround = True

    # Jump with gravity
    # Just give the player a upward speed
    def jump(self):
        if self.onGround:
            self.speedy = -20
            self.onGround = False

    # The player stands on tiptoe
    # Set gravity to 0 to stablize the player
    def tiptoe(self):
        if self.onGround:
            self.gravity = 0
            if (self.offsety > self.canvasHeight + \
                (self.startCentroidy - self.centroidy) - \
                2*self.height - self.width/2):
                self.offsety -= self.tiptoeSpeedy
            else:
                self.offsety > self.canvasHeight + \
                (self.startCentroidy - self.centroidy) - \
                2*self.height - self.width/2

    # Cannot work so far
    def crouch(self):
        if self.onGround:
            self.gravity = 0
            if (self.offsety > self.canvasHeight - self.height):
                self.offsety += self.tiptoeSpeedy      
            else:
                self.offsety = self.canvasHeight - self.height
        
    # The pygame.mask.Mask.outline's return outline coordinates are alwas
    # near the origin. So I need to calculate real coordinates by adding 
    # the offset.
    def getRealOutline(self, outline):
        realOutline = [None] * len(outline)
        for i in range(len(outline)):
            (x, y) = outline[i]
            dx, dy = self.offsetx, self.offsety
            realOutline[i] = (x + dx, y + dy)
        return realOutline
    
    # Cut another player
    # If another player is cut into two separate pieces, reserve the larger one
    def cutOther(self, otherPlayer):
        otherPlayer.mask.erase(self.mask, 
        (int(self.offsetx - otherPlayer.offsetx), 
         int(self.offsety - otherPlayer.offsety)))
        otherPlayer.mask = otherPlayer.mask.connected_component()

# Player2 inherits most parts of Player1, but I need to overwrite something
# Change player2's color
# Overwrite move(self, keyPressed), so that I can change the keys
class Player2(Player1):
    def __init__(self):
        super().__init__()
        self.color = (255, 235, 0)
        # Born in another place
        self.offsetx = self.canvasWidth - self.width
        self.savePositionx = self.canvasWidth - self.width - 150
    
    # Key controling has been changed.
    def move(self, keyPressed, otherPlayer):
        self.gravity = 1
        if keyPressed[K_SEMICOLON]:
            self.offsetx += self.speedx
        if keyPressed[K_k]:
            self.offsetx -= self.speedx
        if keyPressed[K_l]:
            self.crouch()
        if keyPressed[K_o]:
            self.tiptoe()
        if keyPressed[K_RSHIFT]:
            self.jump()
        if keyPressed[K_j]:
            self.cutOther(otherPlayer)
        if keyPressed[K_m]:
            self.mask = pg.mask.from_surface(self.image)    
            #self.offsetx -= (self.startCentroidy - self.centroidy)
            #self.offsetx -= (self.startCentroidy - self.centroidy) 
        if keyPressed[K_i]:
            self.angle += self.rotateSpeed
            self.rotate()
        if keyPressed[K_p]:
            self.angle -= self.rotateSpeed
            self.rotate()
        if keyPressed[K_PERIOD]:
            self.saveShape()
        if keyPressed[K_COMMA]:
            if self.hasSave:
                self.getShape()
                    
                #self.offsetx -= (self.startCentroidy - self.centroidy)
                #self.offsetx -= (self.startCentroidy - self.centroidy) 

        self.gravityEffect()

class Puzzle(object):
    def __init__(self, level):
        self.level = level
        self.puzzleList = ["level0", "level0", "level2", "level3", "level4",
                            "level5", "level6", "level7"]
        self.imagePosCorrect = [0, 74, -40, 30, 105, 105, 0, 105]
        self.image = pg.image.load(self.puzzleList[self.level] + ".png")
        self.rect = self.image.get_rect()
        self.mask = pg.mask.from_surface(self.image)
        self.canvasWidth = 1200
        self.canvasHeight = 800
        
        (self.width, self.height) = self.mask.get_size()
        self.offsety = self.canvasHeight - 2*self.height - \
                        self.imagePosCorrect[self.level]
        self.offsetx = self.canvasWidth/2 - self.width/2
        self.color = (0, 0, 0)
        
    def drawPuzzle(self, surface):
        self.outline = self.mask.outline()
        realOutline = self.getRealOutline(self.outline)
        pg.draw.lines(surface, self.color, True, realOutline, 3)
        #pg.gfxdraw.polygon(surface, realOutline, self.color)

    def getRealOutline(self, outline):
        realOutline = [None] * len(outline)
        for i in range(len(outline)):
            (x, y) = outline[i]
            dx, dy = self.offsetx, self.offsety
            realOutline[i] = (x + dx, y + dy)
        return realOutline



# Run the game with this class
class Game(object):
    # Set up the screen and create two player
    def __init__(self, level):
        self.level = level
        self.fpsClock = pg.time.Clock()
        self.fpsClock.tick(60)
        self.canvasWidth = 1200
        self.canvasHeight = 800
        self.screen = pg.display.set_mode((self.canvasWidth, self.canvasHeight))

        self.player1 = Player1()
        self.player2 = Player2()
        self.puzzle = Puzzle(self.level)
        self.running = True
        self.fit = 0
        self.persentage = 0
        self.playerOverlap = self.player1.mask.overlap_mask(self.player2.mask,
                            (int(self.player2.offsetx - self.player1.offsetx), 
                            int(self.player2.offsety - self.player1.offsety)))
        self.overlapColor = (0, 255, 255)


    def runGame(self):
        pg.init()
        self.n = Network()
        self.mainLoop()

    def mainLoop(self):
        while self.running:
            player2Info = self.n.send(PlayerInfo(self.player1.offsetx,
                            self.player1.offsety,self.player1.outline))

            self.player2.offsetx = player2Info.offsetx
            self.player2.offsety = player2Info.offsety
            self.player2.outline = player2Info.outline
            for event in pg.event.get():
                if event.type == KEYDOWN:
                    if event.key == K_ESCAPE:
                        running = False
                elif event.type == QUIT:
                    running = False
            self.screen.fill((255,255,255))
            self.update()
            pg.display.update()
            self.checkProgress()

    def update(self):
        keyPressed = pg.key.get_pressed()
        self.player1.move(keyPressed, self.player2)
        #self.player2.move(keyPressed, self.player1)
        self.player1.drawPlayer(self.screen)
        self.player2.drawPlayer(self.screen)
        self.drawOverlap()
        self.puzzle.drawPuzzle(self.screen)
        self.drawProgressBar()

    def checkProgress(self):
       
        player1InPuzzle = self.player1.mask.overlap_mask(self.puzzle.mask,
                            (int(self.puzzle.offsetx - self.player1.offsetx), 
                            int(self.puzzle.offsety - self.player1.offsety)))

        player2InPuzzle = self.player2.mask.overlap_mask(self.puzzle.mask,
                            (int(self.puzzle.offsetx - self.player2.offsetx), 
                            int(self.puzzle.offsety - self.player2.offsety)))

        overlapInPuzzle = player1InPuzzle.overlap_mask(player2InPuzzle,
                            (int(self.player2.offsetx - self.player1.offsetx), 
                            int(self.player2.offsety - self.player1.offsety)))
        
        self.playerOverlap = self.player1.mask.overlap_mask(self.player2.mask,
                            (int(self.player2.offsetx - self.player1.offsetx), 
                            int(self.player2.offsety - self.player1.offsety)))
                            
        
        player1Area = self.player1.mask.count()
        player2Area = self.player2.mask.count()
        playerOverlapArea = self.playerOverlap.count() 
        player1InPuzzleArea = player1InPuzzle.count()
        player2InPuzzleArea = player2InPuzzle.count()
        overlapInPuzzle = overlapInPuzzle.count()
        puzzleArea = self.puzzle.mask.count()
        player1Area = self.player1.mask.count()
        totalPlayerArea = player1Area + player2Area - playerOverlapArea
        inPuzzleTotalPlayerArea = player1InPuzzleArea + player2InPuzzleArea \
            - overlapInPuzzle
        outPuzzleTotalPlayerArea = totalPlayerArea - inPuzzleTotalPlayerArea

        self.fit = (inPuzzleTotalPlayerArea - outPuzzleTotalPlayerArea) \
                    / puzzleArea
        # Modify the persentage
        if self.fit <= 0:
            self.persentage = 0
        else:
            # Impossible to get a perfect fit.
            # So you can get 100% if you have a fit of 0.95
            self.persentage = int(self.fit/0.95*100)
            if self.persentage > 100:
                self.persentage = 100

        # Go to next level after users get 100%
        if (self.persentage == 100):
            self.level += 1
            self.puzzle.__init__(self.level)

    # Draw player1 and player2's overlapping part in anothr color
    # So users know precisely which part will be cut
    def drawOverlap(self):
        overlapOutline = self.playerOverlap.outline()
        if (len(overlapOutline) > 2):
            realOutline = self.getRealOutline(overlapOutline)
            # https://stackoverflow.com/questions/
            # 23071965/display-pygame-mask-on-screen
            pg.draw.polygon(self.screen, self.overlapColor, realOutline, 0)

    def getRealOutline(self, outline):
        realOutline = [None] * len(outline)
        for i in range(len(outline)):
            (x, y) = outline[i]
            dx, dy = self.player1.offsetx, self.player1.offsety
            realOutline[i] = (x + dx, y + dy)
        return realOutline

    def drawProgressBar(self):
        persentageString = str(self.persentage) + '%'
        width = 300
        height = 100
        percentageWidth = width*self.persentage*0.01
        emptyBar = pg.Rect(self.canvasWidth/2 - width/2, height,
                            width, height)
        topLeft = (self.canvasWidth/2 - width/2, height)
        topRight = (self.canvasWidth/2 - width/2 + width, height)
        downLeft = (self.canvasWidth/2 - width/2, height + height)
        downRight = (self.canvasWidth/2 - width/2 + width, height + height)
        progressBar = pg.Rect(self.canvasWidth/2 - width/2, height,
                            percentageWidth, height)
        pg.draw.rect(self.screen, (0,255,127), progressBar)                
        pg.draw.lines(self.screen, (0,0,0), True, 
                    [topLeft, topRight, downRight, downLeft],width = 3)
        pg.font.init()
        fontSize = 80
        font = pg.font.Font(None, fontSize)
        charSurface = font.render(persentageString, True, (178, 34, 34))
        self.screen.blit(charSurface, (self.canvasWidth/2,
                                       height + 20))


if __name__ == '__main__':
    game = Game(0)
    game.runGame()
    pg.quit()

