# Name: Juncong Li
# Andrew ID: juncongl


'''
This game is mainly based on a switch game called Snipperclips.
What's new is that the users can customize their own puzzle shape without
much effort.
For drawing the players, I just used the shapes of the image and I never drew 
the images. I only need the mask of the image.
'''


import random, sys, time, math
import pygame as pg
from pygame.locals import *
import socket

# Copied from https://www.youtube.com/watch?v=McoDjOCb2Zo
class Network:
    def __init__(self):
        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        #hostname = socket.gethostname()
        #ip = socket.gethostbyname(hostname)
        self.server = '192.168.3.6'
        self.port = 5555
        self.addr = (self.server, self.port)
        self.pos = self.connect()
    
    def getPos(self):
        return self.pos

    # Connect with the server
    def connect(self):
        try:
            self.client.connect(self.addr)
            return self.client.recv(2048).decode()
        except:
            pass
    
    # Send massage to the server
    def send(self, data):
        try:
            self.client.send(str.encode(data))
            return self.client.recv(2048).decode()
        except socket.error as e:
            print(e)

        
class Player1(pg.sprite.Sprite):
    def __init__(self):
        pg.sprite.Sprite.__init__(self)
        # Just need the shape of the image
        self.startImage = pg.image.load('playerShape.png')
        self.image = self.startImage
        #self.rect = self.image.get_rect()

        # This mask is really important and it represents the player
        self.startMask = pg.mask.from_surface(self.image)
        # Initialize the mask
        self.mask = self.startMask

        self.canvasWidth = 1200
        self.canvasHeight = 800
        (self.width, self.height) = self.mask.get_size()
        self.offsetx = 0
        self.offsety = 0
        self.speedx = 5
        self.speedy = 0 # Based on gravity
        self.gravity = 3
        self.tiptoeSpeedy = 20
        self.acceleartion = 10
        self.onGround = False
        self.color = (0,255,0)
        self.angle = 0
        self.rotateSpeed = 3
        (self.startCentroidx, self.startCentroidy) = self.startMask.centroid()
        (self.centroidx, self.centroidy) = \
        (self.startCentroidx, self.startCentroidy)

    def drawPlayer(self, surface):
        self.outline = self.mask.outline()
        realOutline = self.getRealOutline(self.outline)
        # https://stackoverflow.com/questions/
        # 23071965/display-pygame-mask-on-screen
        pg.draw.polygon(surface, self.color, realOutline, 0)

    '''
    The function shows how player 1 can control the game.
    'a' and 'd' are moving to left and right.
    'w' is tiptoing and 's' is crounching (doesn't work now)
    '''
    def move(self, keyPressed, otherPlayer):
        self.gravity = 3
        if keyPressed[K_d]:
            self.offsetx += self.speedx
        if keyPressed[K_a]:
            self.offsetx -= self.speedx
        if keyPressed[K_s]:
            self.crouch()
        if keyPressed[K_w]:
            self.tiptoe()
        if keyPressed[K_LSHIFT]:
            self.jump()
        if keyPressed[K_f]:
            self.cutOther(otherPlayer)
        if keyPressed[K_c]:
            self.mask = pg.mask.from_surface(self.startImage)
        if keyPressed[K_q]:
            self.angle += self.rotateSpeed
            self.rotate()
        if keyPressed[K_e]:
            self.angle -= self.rotateSpeed
            self.rotate()

        # self.gravityEffect()
     
    # Rotate. Have padding issues
    # Need to fix the centroid
    def rotate(self):
        (self.oldCentroidx, self.oldCentroidy) = self.mask.centroid()
        self.image = pg.transform.rotate(self.startImage, self.angle)
        self.rotatedMask = pg.mask.from_surface(self.image)
        self.mask = self.rotatedMask
        (self.centroidx, self.centroidy) = self.mask.centroid()
        # Fix the centroid
        self.offsetx -= (self.centroidx - self.oldCentroidx)
        self.offsety -= (self.centroidy - self.oldCentroidy)
        
    def gravityEffect(self):
        self.speedy += self.gravity
        self.offsety += self.speedy

        if (self.offsety + self.height + self.width/2 - 
        (self.startCentroidy - self.centroidy) >= self.canvasHeight):

            self.offsety = (self.canvasHeight - self.height - self.width/2
                            + (self.startCentroidy - self.centroidy))
            self.speedy = 0
            self.onGround = True

    # Jump with gravity
    # Just give the player a upward speed
    def jump(self):
        if self.onGround:
            self.speedy = -50
            self.onGround = False

    # The player stands on tiptoe
    # Set gravity to 0 to stablize the player
    def tiptoe(self):
        if self.onGround:
            self.gravity = 0
            if (self.offsety > self.canvasHeight - self.height - self.width):
                self.offsety -= self.tiptoeSpeedy      
            else:
                self.offsety = self.canvasHeight - self.height - self.width

    # Cannot work so far
    def crouch(self):
        if self.onGround:
            self.gravity = 0
            if (self.offsety > self.canvasHeight - self.height):
                self.offsety += self.tiptoeSpeedy      
            else:
                self.offsety = self.canvasHeight - self.height
        
    # The pygame.mask.Mask.outline's return outline coordinates are alwas
    # near the origin. So I need to calculate real coordinates by adding 
    # the offset.
    def getRealOutline(self, outline):
        realOutline = [None] * len(outline)
        for i in range(len(outline)):
            (x, y) = outline[i]
            dx, dy = self.offsetx, self.offsety
            realOutline[i] = (x + dx, y + dy)
        return realOutline
    
    # Cut another player
    # If another player is cut into two separate pieces, reserve the larger one
    def cutOther(self, otherPlayer):
        otherPlayer.mask.erase(self.mask, 
        (int(self.offsetx - otherPlayer.offsetx), 
         int(self.offsety - otherPlayer.offsety)))
        otherPlayer.mask = otherPlayer.mask.connected_component()

# Player2 inherits most parts of Player1, but I need to overwrite something
# Change player2's color
# Overwrite move(self, keyPressed), so that I can change the keys
class Player2(Player1):
    def __init__(self):
        super().__init__()
        self.color = (255,0,0)
        # Born in another place
        self.offsetx = self.canvasWidth - self.width
    
    # Key controling has been changed.
    def move(self, keyPressed, otherPlayer):
        self.gravity = 5
        if keyPressed[K_SEMICOLON]:
            self.offsetx += self.speedx
        if keyPressed[K_k]:
            self.offsetx -= self.speedx
        if keyPressed[K_l]:
            self.crouch()
        if keyPressed[K_o]:
            self.tiptoe()
        if keyPressed[K_RSHIFT]:
            self.jump()
        if keyPressed[K_j]:
            self.cutOther(otherPlayer)
        if keyPressed[K_m]:
            self.mask = pg.mask.from_surface(self.image)        
        if keyPressed[K_i]:
            self.angle += self.rotateSpeed
            self.rotate()
        if keyPressed[K_p]:
            self.angle -= self.rotateSpeed
            self.rotate()

        self.gravityEffect()

class Puzzle(object):
    def __init__(self):
        self.image = pg.image.load("puzzle1.png")
        self.rect = self.image.get_rect()
        # This mask is really important and it represents the player
        self.mask = pg.mask.from_surface(self.image)
        self.canvasWidth = 1200
        self.canvasHeight = 800
        (self.width, self.height) = self.mask.get_size()
        self.offsety = self.canvasHeight - self.height - self.width/2
        self.offsetx = self.canvasWidth/2
        self.color = (0, 0, 0)
        
    def drawPuzzle(self, surface):
        self.outline = self.mask.outline()
        realOutline = self.getRealOutline(self.outline)
        # https://stackoverflow.com/questions/
        # 23071965/display-pygame-mask-on-screen
        pg.draw.lines(surface, self.color, True, realOutline, 1)

    def getRealOutline(self, outline):
        realOutline = [None] * len(outline)
        for i in range(len(outline)):
            (x, y) = outline[i]
            dx, dy = self.offsetx, self.offsety
            realOutline[i] = (x + dx, y + dy)
        return realOutline



# Run the game with this class
class Game(object):

    # Set up the screen and create two player
    def __init__(self):
        self.fpsClock = pg.time.Clock()
        self.fpsClock.tick(60)
        self.canvasWidth = 1200
        self.canvasHeight = 800
        self.screen = pg.display.set_mode((self.canvasWidth, self.canvasHeight))        
        self.n = Network()
        self.startPos = readPos(self.n.getPos())
        self.player1 = Player1()
        self.player1.offsetx = self.startPos[0]
        self.player1.offsety = self.startPos[1]
        self.player2 = Player1() ###

        self.puzzle = Puzzle()
        self.running = True


    def runGame(self):
        pg.init()
        self.mainLoop()

    def mainLoop(self):

        while self.running:
            player2Pos = readPos(self.n.send(makePos((self.player1.offsetx,
                                          self.player1.offsety))))
            self.player2.offsetx = player2Pos[0]
            self.player2.offsety = player2Pos[1]
            for event in pg.event.get():
                if event.type == KEYDOWN:
                    if event.key == K_ESCAPE:
                        self.running = False
                elif event.type == QUIT:
                    self.running = False
            self.screen.fill((255,255,255))
            self.update()
            pg.display.update()
            # self.checkWin()

    def update(self):
        keyPressed = pg.key.get_pressed()
        self.player1.move(keyPressed, self.player2)
        self.player1.drawPlayer(self.screen)
        self.player2.drawPlayer(self.screen)
        self.puzzle.drawPuzzle(self.screen)

    def checkWin(self):
        # Must copy because I use some destructive functions
        self.totalMask = self.player1.mask.copy()
        # Get the total mask
        self.totalMask.draw(self.player2.mask, 
                            (int(self.player1.offsetx - self.player2.offsetx), 
                            int(self.player1.offsety - self.player2.offsety)))
        totalArea = self.totalMask.count()
        overlapArea = self.totalMask.overlap_area(self.puzzle.mask,
                            (int(self.player1.offsetx - self.puzzle.offsetx), 
                            int(self.player1.offsety - self.puzzle.offsety)))
        puzzleArea = self.puzzle.mask.count()
        self.completion = overlapArea/puzzleArea
        print(self.completion)
    
# For packaging the position before sending and read position after receiving
def readPos(string):
    strList = string.split(",")
    return int(strList[0]), int(strList[1])

def makePos(tuple):
    return str(tuple[0]) + ',' + str(tuple[1])
    


if __name__ == '__main__':
    game = Game()
    game.runGame()
    pg.quit()